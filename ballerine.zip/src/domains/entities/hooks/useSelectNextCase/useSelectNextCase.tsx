import { useCallback } from 'react';

export const useSelectNextCase = () => {
  return useCallback(() => {
    // @TODO: Implement
    throw new Error('Not implemented');
  }, []);
};
