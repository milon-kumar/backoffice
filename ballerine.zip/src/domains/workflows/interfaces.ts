export interface IWorkflowId {
  workflowId: string;
}
