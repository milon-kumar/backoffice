export const isNullish = (value: unknown) => value === null || value === undefined;
