export const underscoreToSpace = (str: string) => str?.replace(/_/g, ' ');
