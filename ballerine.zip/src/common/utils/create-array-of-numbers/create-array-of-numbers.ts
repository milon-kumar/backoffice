export const createArrayOfNumbers = (length: number) => Array.from({ length }, (_, i) => i + 1);
