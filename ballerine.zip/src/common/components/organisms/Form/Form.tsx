import { FormProvider } from 'react-hook-form';

export const Form = FormProvider;
