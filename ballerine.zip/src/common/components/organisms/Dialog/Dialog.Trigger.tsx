import * as DialogPrimitive from '@radix-ui/react-dialog';

export const DialogTrigger = DialogPrimitive.Trigger;
