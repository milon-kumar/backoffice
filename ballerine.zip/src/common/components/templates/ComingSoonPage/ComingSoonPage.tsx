export const ComingSoonPage = () => {
  return (
    <section className={`container col-span-full mx-auto mt-8 flex w-full justify-center p-4`}>
      <h2 className={`text-6xl font-bold`}>Coming Soon!</h2>
    </section>
  );
};
