import { motion } from 'framer-motion';
import { Button } from '../../atoms/Button/Button';

export const MotionButton = motion(Button);
