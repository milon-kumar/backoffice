import { Badge } from '@ballerine/ui';
import { motion } from 'framer-motion';

export const MotionBadge = motion(Badge);
