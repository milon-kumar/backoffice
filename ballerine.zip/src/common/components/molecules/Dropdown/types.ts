export type DropdownOption<TItem> = {
  id: string;
  value: TItem;
};
