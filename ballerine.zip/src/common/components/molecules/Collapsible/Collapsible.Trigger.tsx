import * as CollapsiblePrimitive from '@radix-ui/react-collapsible';

export const CollapsibleTrigger = CollapsiblePrimitive.CollapsibleTrigger;
