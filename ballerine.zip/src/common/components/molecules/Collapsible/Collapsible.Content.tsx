import * as CollapsiblePrimitive from '@radix-ui/react-collapsible';

export const CollapsibleContent = CollapsiblePrimitive.CollapsibleContent;
