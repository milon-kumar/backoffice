import { motion } from 'framer-motion';
import * as ScrollArea from '@radix-ui/react-scroll-area';

export const Root = motion(ScrollArea.Root);
