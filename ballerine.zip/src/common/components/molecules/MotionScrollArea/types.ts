import { ComponentProps } from 'react';
import { Root } from './MotionScrollArea.Root';

export type TMotionScrollAreaProps = ComponentProps<typeof Root>;
