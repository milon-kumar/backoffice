import { Root } from './MotionScrollArea.Root';

export interface IMotionScrollAreaChildren {
  Root: typeof Root;
}
