import * as DropdownMenuPrimitive from '@radix-ui/react-dropdown-menu';

export const DropdownMenuPortal = DropdownMenuPrimitive.Portal;
