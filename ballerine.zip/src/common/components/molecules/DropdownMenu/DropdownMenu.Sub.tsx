import * as DropdownMenuPrimitive from '@radix-ui/react-dropdown-menu';

export const DropdownMenuSub = DropdownMenuPrimitive.Sub;
