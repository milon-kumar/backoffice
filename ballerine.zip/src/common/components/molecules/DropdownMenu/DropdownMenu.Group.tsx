import * as DropdownMenuPrimitive from '@radix-ui/react-dropdown-menu';

export const DropdownMenuGroup = DropdownMenuPrimitive.Group;
