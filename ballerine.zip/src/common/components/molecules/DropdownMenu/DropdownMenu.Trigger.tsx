import * as DropdownMenuPrimitive from '@radix-ui/react-dropdown-menu';

export const DropdownMenuTrigger = DropdownMenuPrimitive.Trigger;
