export interface IPaginationWithIconProps {
  iconOnly?: boolean;
}
