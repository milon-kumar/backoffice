import * as SelectPrimitive from '@radix-ui/react-select';

export const SelectGroup = SelectPrimitive.Group;
