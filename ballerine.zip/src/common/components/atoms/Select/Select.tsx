import * as SelectPrimitive from '@radix-ui/react-select';

export const Select = SelectPrimitive.Root;
