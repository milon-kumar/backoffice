import * as SelectPrimitive from '@radix-ui/react-select';

export const SelectValue = SelectPrimitive.Value;
