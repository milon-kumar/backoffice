import { ButtonComponent } from '../../../types';

export type IMagnifyingGlassButtonProps = ButtonComponent;
