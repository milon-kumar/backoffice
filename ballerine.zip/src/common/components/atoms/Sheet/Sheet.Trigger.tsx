import * as SheetPrimitive from '@radix-ui/react-dialog';

export const SheetTrigger = SheetPrimitive.Trigger;
