import { ButtonComponent } from '../../../types';

export type TSecondaryButtonProps = ButtonComponent;
