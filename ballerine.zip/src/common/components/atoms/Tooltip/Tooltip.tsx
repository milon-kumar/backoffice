import * as TooltipPrimitive from '@radix-ui/react-tooltip';

export const Tooltip = TooltipPrimitive.Root;
