import * as TooltipPrimitive from '@radix-ui/react-tooltip';

export const TooltipTrigger = TooltipPrimitive.Trigger;
