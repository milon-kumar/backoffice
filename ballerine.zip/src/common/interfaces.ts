import { TAction, TResource } from './types';

export interface IGlobalToastContext {
  resource: TResource;
  action: TAction;
}
