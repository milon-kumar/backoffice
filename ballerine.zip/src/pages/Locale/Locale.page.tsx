import { FunctionComponent } from 'react';
import { Outlet } from 'react-router-dom';

export const Locale: FunctionComponent = () => <Outlet />;
