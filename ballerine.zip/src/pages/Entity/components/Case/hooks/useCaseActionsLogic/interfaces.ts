export interface IUseActions {
  workflowId: string;
  fullName: string;
}
